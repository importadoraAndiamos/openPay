function CambioValorCalificacion($valor){
        $('#calificacion').val($valor)
}

  


