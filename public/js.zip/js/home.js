
$("#slcArea").change(function(event) {

    $.get("profesionPorArea/" + event.target.value + "", function(response) {

        $('#slcProfesion').empty();
        $('#slcEspecialidad').empty();
        $("#slcProfesion").append("<option value = ' '>   PROFESIONES    </option>");
        $("#slcEspecialidad").append("<option value = ' '>  ESPECIALIDADES    </option>");
        for (i = 0; i < response.length; i++) {

            $("#slcProfesion").append("<option value = '" + response[i].id + " '> " + response[i].nombreProfesion + "</option>");

        }
    })

});

$("#slcProfesion").change(function(event) {

    $.get("especialidadPorProfesion/" + event.target.value + "", function(response) {

        $('#slcEspecialidad').empty();
        $("#slcEspecialidad").append("<option value = ' '>   ESPECIALIDADES    </option>");
        for (i = 0; i < response[0].length; i++) {

            $("#slcEspecialidad").append("<option value ='https://sprofesional.zaabra.co/"+
                                            //este if se hace para la ruta que no sea de estudiantes
                                            (response[1][0].ruta != 'Estudiantes' ? "galeriaProfesionales/" : "galeriaEstudiantes/")  +    

                                             response[1][0].ruta + //esta ruta pertenece al area
                                             "/"+ response[2][0].ruta  + //esta ruta pertenece a la profesion 
                                             "/" + response[0][i].ruta +" '>"+ //esta ruta pertenece especialidad
                                             response[0][i].nombreEspecialidad + 
                                            "</option>");

        }
    })

});

$("#slcAreaMiPerf").change(function(event) {

    $.get("profesionPorArea/" + event.target.value + "", function(response) {

        $('#slcProfesionMiPerf').empty();
        $('#slcEspecialidadMiPerf').empty();
        $("#slcProfesionMiPerf").append("<option value = ' '>   PROFESIONES    </option>");
        $("#slcEspecialidadMiPerf").append("<option value = ' '>  ESPECIALIDADES    </option>");
        for (i = 0; i < response.length; i++) {

            $("#slcProfesionMiPerf").append("<option value = '" + response[i].id + " '> " + response[i].nombreProfesion + "</option>");

        }
    })

});

$("#slcProfesionMiPerf").change(function(event) {

    $.get("especialidadPorProfesion/" + event.target.value + "", function(response) {

        $('#slcEspecialidadMiPerf').empty();
        $("#slcEspecialidadMiPerf").append("<option value = ' '>   ESPECIALIDADES    </option>");
        for (i = 0; i < response[0].length; i++) {

            $("#slcEspecialidadMiPerf").append("<option value ='"+ response[0][i].id + " '>"+ //esta ruta pertenece especialidad
                                             response[0][i].nombreEspecialidad + 
                                            "</option>");

        }
    })

});
//codigo para el bucador oculto del icono de la lupa en modo responsive de 320 a 768
$('#btn-buscadorOculto').click(function() {
    $('#buscadorOculto').toggleClass('ocultaBuscador');
});

//codigo para el ojo de la caja de texto del LOGIN
$(".toggle-password1").click(function() {

    $(this).toggleClass("fa-eye fa-eye-slash");
    var input = $($(this).attr("toggle"));
    if (input.attr("type") == "password") {
      input.attr("type", "text");
    } else {
      input.attr("type", "password");
    }
});

//codigo para animacion del input banner profesionales
$('.icono-lupa').hover(
    function() {$(".filaPrincipalImagenes").show("slow","swing")}
    //function() {$('.filaPrincipalImagenes').toggleClass('mostrarinput')}
    //function() {$(".filaPrincipalImagenes").css("display", "block")}
)

$(document).ready(function() {
    $("#contenedor-areas-home1").addClass('oculta-contenedor-profesiones-home');
    $("#contenedor-areas-home2").addClass('oculta-contenedor-profesiones-home');
    $("#contenedor-areas-home3").addClass('oculta-contenedor-profesiones-home');
    $("#contenedor-areas-home4").addClass('oculta-contenedor-profesiones-home');
    $("#contenedor-areas-home5").addClass('oculta-contenedor-profesiones-home');
    $("#contenedor-areas-home6").addClass('oculta-contenedor-profesiones-home');

    $("#dropdownMenuButton1" ).click(function() {
        /*$("#contenedor-areas-home1").slideToggle('oculta-contenedor-profesiones-home');
        $("#contenedor-areas-home1").css("display", "inline-flex");*/
        $("#contenedor-areas-home1").removeClass('oculta-contenedor-profesiones-home');
        $("#contenedor-areas-home1").addClass('animate__animated animate__backInDown');
        $("#contenedor-areas-home2").addClass('oculta-contenedor-profesiones-home');
        $("#contenedor-areas-home3").addClass('oculta-contenedor-profesiones-home');
        $("#contenedor-areas-home4").addClass('oculta-contenedor-profesiones-home');
        $("#contenedor-areas-home5").addClass('oculta-contenedor-profesiones-home');
        $("#contenedor-areas-home6").addClass('oculta-contenedor-profesiones-home');
        setValorElementoLocal("areaActual","Economico")

    });
      $("#dropdownMenuButton2" ).click(function() {
        /*$("#contenedor-areas-home2").slideToggle('oculta-contenedor-profesiones-home');
        $("#contenedor-areas-home2").css("display", "inline-flex");*/
        $("#contenedor-areas-home1").addClass('oculta-contenedor-profesiones-home');
        $("#contenedor-areas-home2").removeClass('oculta-contenedor-profesiones-home');
        $("#contenedor-areas-home2").addClass('animate__animated animate__backInDown');
        $("#contenedor-areas-home3").addClass('oculta-contenedor-profesiones-home');
        $("#contenedor-areas-home4").addClass('oculta-contenedor-profesiones-home');
        $("#contenedor-areas-home5").addClass('oculta-contenedor-profesiones-home');
        $("#contenedor-areas-home6").addClass('oculta-contenedor-profesiones-home');
        setValorElementoLocal("areaActual","Salud")
      });
      $("#dropdownMenuButton3" ).click(function() {
        /*$("#contenedor-areas-home3").slideToggle('oculta-contenedor-profesiones-home');
        $("#contenedor-areas-home3").css("display", "inline-flex");*/
        $("#contenedor-areas-home1").addClass('oculta-contenedor-profesiones-home');
        $("#contenedor-areas-home2").addClass('oculta-contenedor-profesiones-home');
        $("#contenedor-areas-home3").removeClass('oculta-contenedor-profesiones-home');
        $("#contenedor-areas-home3").addClass('animate__animated animate__backInDown');
        $("#contenedor-areas-home4").addClass('oculta-contenedor-profesiones-home');
        $("#contenedor-areas-home5").addClass('oculta-contenedor-profesiones-home');
        $("#contenedor-areas-home6").addClass('oculta-contenedor-profesiones-home');
        setValorElementoLocal("areaActual","Ingenieria")
      });
      $("#dropdownMenuButton4" ).click(function() {
        /*$("#contenedor-areas-home4").slideToggle('oculta-contenedor-profesiones-home');
        $("#contenedor-areas-home4").css("display", "inline-flex");*/
        $("#contenedor-areas-home1").addClass('oculta-contenedor-profesiones-home');
        $("#contenedor-areas-home2").addClass('oculta-contenedor-profesiones-home');
        $("#contenedor-areas-home3").addClass('oculta-contenedor-profesiones-home');
        $("#contenedor-areas-home4").removeClass('oculta-contenedor-profesiones-home');
        $("#contenedor-areas-home4").addClass('animate__animated animate__backInDown');
        $("#contenedor-areas-home5").addClass('oculta-contenedor-profesiones-home');
        $("#contenedor-areas-home6").addClass('oculta-contenedor-profesiones-home');
        setValorElementoLocal("areaActual","Docente")
      });
      $("#dropdownMenuButton5" ).click(function() {
        /*$("#contenedor-areas-home5").slideToggle('oculta-contenedor-profesiones-home');
        $("#contenedor-areas-home5").css("display", "inline-flex");*/
        $("#contenedor-areas-home1").addClass('oculta-contenedor-profesiones-home');
        $("#contenedor-areas-home2").addClass('oculta-contenedor-profesiones-home');
        $("#contenedor-areas-home3").addClass('oculta-contenedor-profesiones-home');
        $("#contenedor-areas-home4").addClass('oculta-contenedor-profesiones-home');
        $("#contenedor-areas-home5").removeClass('oculta-contenedor-profesiones-home');
        $("#contenedor-areas-home5").addClass('animate__animated animate__backInDown');
        $("#contenedor-areas-home6").addClass('oculta-contenedor-profesiones-home');
        setValorElementoLocal("areaActual","Tecnologo")
      });
      $("#dropdownMenuButton6" ).click(function() {
        /*$("#contenedor-areas-home6").slideToggle('oculta-contenedor-profesiones-home');
        $("#contenedor-areas-home6").css("display", "inline-flex");*/
        $("#contenedor-areas-home1").addClass('oculta-contenedor-profesiones-home');
        $("#contenedor-areas-home2").addClass('oculta-contenedor-profesiones-home');
        $("#contenedor-areas-home3").addClass('oculta-contenedor-profesiones-home');
        $("#contenedor-areas-home4").addClass('oculta-contenedor-profesiones-home');
        $("#contenedor-areas-home5").addClass('oculta-contenedor-profesiones-home');
        $("#contenedor-areas-home6").removeClass('oculta-contenedor-profesiones-home');
        $("#contenedor-areas-home6").addClass('animate__animated animate__backInDown');
        setValorElementoLocal("areaActual","Estudiantes")
      });
});

