$(window).load(function() {
    $('#toggle').click(function() {
        $('.slide-in').toggleClass('show');
    });
    $('#toggle').trigger('click');
});

$(window).load(function() {
    $('#botonmuestra').click(function() {
        $('.doors').addClass('in');
    });
    $('#botonmuestra').removeClass('in');
});


$(document).ready(function() {

    $("#contenedor-certificados").addClass( "oculto" );
    $("#contenedor-estudios").addClass( "oculto" );
    $("#contenedor-publicaciones").addClass( "oculto" );
    $("#contenedor-asociaciones").addClass( "oculto" );
    $("#contenedor-procedimientos").addClass( "oculto" );
    $("#contenedor-trataminetos").addClass( "oculto" );
    $("#contenedor-testimonios").addClass( "oculto" );


    $("#divEstudios" ).click(function() {       
        $("#divCertificados").removeClass( "boton-carrusel-hover");
        $("#spanCertificados").removeClass( "spanhover");
        $("#divPublicaciones").removeClass( "boton-carrusel-hover");
        $("#spanPublicaciones").removeClass( "spanhover");
        $("#divAsociaciones").removeClass( "boton-carrusel-hover");
        $("#spanAsociaciones").removeClass( "spanhover");
        $("#divProcedimientos").removeClass( "boton-carrusel-hover");
        $("#spanProcedimientos").removeClass( "spanhover");
        $("#divTrataminetos").removeClass( "boton-carrusel-hover");
        $("#spanTratamientos").removeClass( "spanhover");
        $("#divTestimonios").removeClass( "boton-carrusel-hover");
        $("#spanTestimonios").removeClass( "spanhover");
        $("#divEstudios").addClass( "boton-carrusel-hover");
        $("#spanEstudios").addClass( "spanhover");

        $("#contenedor-certificados").addClass( "oculto" );
        $("#contenedor-publicaciones").addClass( "oculto" );
        $("#contenedor-asociaciones").addClass( "oculto" );
        $("#contenedor-procedimientos").addClass( "oculto" );
        $("#contenedor-trataminetos").addClass( "oculto" );
        $("#contenedor-testimonios").addClass( "oculto" );
        $("#contenedor-estudios").removeClass( "oculto" )
    }); 

    $("#divCertificados" ).click(function() {
        $("#divPublicaciones").removeClass( "boton-carrusel-hover");
        $("#spanPublicaciones").removeClass( "spanhover");
        $("#divAsociaciones").removeClass( "boton-carrusel-hover");
        $("#spanAsociaciones").removeClass( "spanhover");
        $("#divProcedimientos").removeClass( "boton-carrusel-hover");
        $("#spanProcedimientos").removeClass( "spanhover");
        $("#divTrataminetos").removeClass( "boton-carrusel-hover");
        $("#spanTratamientos").removeClass( "spanhover");
        $("#divTestimonios").removeClass( "boton-carrusel-hover");
        $("#spanTestimonios").removeClass( "spanhover");
        $("#divEstudios").removeClass( "boton-carrusel-hover");
        $("#spanEstudios").removeClass( "spanhover");
        $("#divCertificados").addClass( "boton-carrusel-hover");
        $("#spanCertificados").addClass( "spanhover");


        $("#contenedor-certificados").removeClass( "oculto" );
        $("#contenedor-publicaciones").addClass( "oculto" );
        $("#contenedor-asociaciones").addClass( "oculto" );
        $("#contenedor-procedimientos").addClass( "oculto" );
        $("#contenedor-trataminetos").addClass( "oculto" );
        $("#contenedor-testimonios").addClass( "oculto" );
        $("#contenedor-estudios").addClass( "oculto" )
    });  

    $("#divPublicaciones" ).click(function() {
        $("#divAsociaciones").removeClass( "boton-carrusel-hover");
        $("#spanAsociaciones").removeClass( "spanhover");
        $("#divProcedimientos").removeClass( "boton-carrusel-hover");
        $("#spanProcedimientos").removeClass( "spanhover");
        $("#divTrataminetos").removeClass( "boton-carrusel-hover");
        $("#spanTratamientos").removeClass( "spanhover");
        $("#divTestimonios").removeClass( "boton-carrusel-hover");
        $("#spanTestimonios").removeClass( "spanhover");
        $("#divEstudios").removeClass( "boton-carrusel-hover");
        $("#spanEstudios").removeClass( "spanhover");
        $("#divCertificados").removeClass( "boton-carrusel-hover");
        $("#spanCertificados").removeClass( "spanhover");
        $("#divPublicaciones").addClass( "boton-carrusel-hover");
        $("#spanPublicaciones").addClass( "spanhover");


        $("#contenedor-certificados").addClass( "oculto" );
        $("#contenedor-publicaciones").removeClass( "oculto" );
        $("#contenedor-asociaciones").addClass( "oculto" );
        $("#contenedor-procedimientos").addClass( "oculto" );
        $("#contenedor-trataminetos").addClass( "oculto" );
        $("#contenedor-testimonios").addClass( "oculto" );
        $("#contenedor-estudios").addClass( "oculto" )
    });
    
    
    $("#divAsociaciones" ).click(function() {
        $("#divProcedimientos").removeClass( "boton-carrusel-hover");
        $("#spanProcedimientos").removeClass( "spanhover");
        $("#divTrataminetos").removeClass( "boton-carrusel-hover");
        $("#spanTratamientos").removeClass( "spanhover");
        $("#divTestimonios").removeClass( "boton-carrusel-hover");
        $("#spanTestimonios").removeClass( "spanhover");
        $("#divEstudios").removeClass( "boton-carrusel-hover");
        $("#spanEstudios").removeClass( "spanhover");
        $("#divCertificados").removeClass( "boton-carrusel-hover");
        $("#spanCertificados").removeClass( "spanhover");
        $("#divPublicaciones").removeClass( "boton-carrusel-hover");
        $("#spanPublicaciones").removeClass( "spanhover");
        $("#divAsociaciones").addClass( "boton-carrusel-hover");
        $("#spanAsociaciones").addClass( "spanhover");


        $("#contenedor-certificados").addClass( "oculto" );
        $("#contenedor-publicaciones").addClass( "oculto" );
        $("#contenedor-asociaciones").removeClass( "oculto" );
        $("#contenedor-procedimientos").addClass( "oculto" );
        $("#contenedor-trataminetos").addClass( "oculto" );
        $("#contenedor-testimonios").addClass( "oculto" );
        $("#contenedor-estudios").addClass( "oculto" )
    });

    $("#divProcedimientos" ).click(function() {
        $("#divTrataminetos").removeClass( "boton-carrusel-hover");
        $("#spanTratamientos").removeClass( "spanhover");
        $("#divTestimonios").removeClass( "boton-carrusel-hover");
        $("#spanTestimonios").removeClass( "spanhover");
        $("#divEstudios").removeClass( "boton-carrusel-hover");
        $("#spanEstudios").removeClass( "spanhover");
        $("#divCertificados").removeClass( "boton-carrusel-hover");
        $("#spanCertificados").removeClass( "spanhover");
        $("#divPublicaciones").removeClass( "boton-carrusel-hover");
        $("#spanPublicaciones").removeClass( "spanhover");
        $("#divAsociaciones").removeClass( "boton-carrusel-hover");
        $("#spanAsociaciones").removeClass( "spanhover");
        $("#divProcedimientos").addClass( "boton-carrusel-hover");
        $("#spanProcedimientos").addClass( "spanhover");


        $("#contenedor-certificados").addClass( "oculto" );
        $("#contenedor-publicaciones").addClass( "oculto" );
        $("#contenedor-asociaciones").addClass( "oculto" );
        $("#contenedor-procedimientos").removeClass( "oculto" );
        $("#contenedor-trataminetos").addClass( "oculto" );
        $("#contenedor-testimonios").addClass( "oculto" );
        $("#contenedor-estudios").addClass( "oculto" )
    });

    $("#divTrataminetos" ).click(function() {
        $("#divTestimonios").removeClass( "boton-carrusel-hover");
        $("#spanTestimonios").removeClass( "spanhover");
        $("#divEstudios").removeClass( "boton-carrusel-hover");
        $("#spanEstudios").removeClass( "spanhover");
        $("#divCertificados").removeClass( "boton-carrusel-hover");
        $("#spanCertificados").removeClass( "spanhover");
        $("#divPublicaciones").removeClass( "boton-carrusel-hover");
        $("#spanPublicaciones").removeClass( "spanhover");
        $("#divAsociaciones").removeClass( "boton-carrusel-hover");
        $("#spanAsociaciones").removeClass( "spanhover");
        $("#divProcedimientos").removeClass( "boton-carrusel-hover");
        $("#spanProcedimientos").removeClass( "spanhover");
        $("#divTrataminetos").addClass( "boton-carrusel-hover");
        $("#spanTratamientos").addClass( "spanhover");


        $("#contenedor-certificados").addClass( "oculto" );
        $("#contenedor-publicaciones").addClass( "oculto" );
        $("#contenedor-asociaciones").addClass( "oculto" );
        $("#contenedor-procedimientos").addClass( "oculto" );
        $("#contenedor-trataminetos").removeClass( "oculto" );
        $("#contenedor-testimonios").addClass( "oculto" );
        $("#contenedor-estudios").addClass( "oculto" )
    });
    
    $("#divTestimonios" ).click(function() {
        $("#divEstudios").removeClass( "boton-carrusel-hover");
        $("#spanEstudios").removeClass( "spanhover");
        $("#divCertificados").removeClass( "boton-carrusel-hover");
        $("#spanCertificados").removeClass( "spanhover");
        $("#divPublicaciones").removeClass( "boton-carrusel-hover");
        $("#spanPublicaciones").removeClass( "spanhover");
        $("#divAsociaciones").removeClass( "boton-carrusel-hover");
        $("#spanAsociaciones").removeClass( "spanhover");
        $("#divProcedimientos").removeClass( "boton-carrusel-hover");
        $("#spanProcedimientos").removeClass( "spanhover");
        $("#divTrataminetos").removeClass( "boton-carrusel-hover");
        $("#spanTratamientos").removeClass( "spanhover");
        $("#divTestimonios").addClass( "boton-carrusel-hover");
        $("#spanTestimonios").addClass( "spanhover");

        $("#contenedor-certificados").addClass( "oculto" );
        $("#contenedor-publicaciones").addClass( "oculto" );
        $("#contenedor-asociaciones").addClass( "oculto" );
        $("#contenedor-procedimientos").addClass( "oculto" );
        $("#contenedor-trataminetos").addClass( "oculto" );
        $("#contenedor-testimonios").removeClass( "oculto" );
        $("#contenedor-estudios").addClass( "oculto" )
    });  
})




$(document).ready(function() {

    $("#contenedor-certificados-cel").addClass( "oculto" );
    $("#contenedor-estudios-cel").addClass( "oculto" );
    $("#contenedor-publicaciones-cel").addClass( "oculto" );
    $("#contenedor-asociaciones-cel").addClass( "oculto" );
    $("#contenedor-procedimientos-cel").addClass( "oculto" );
    $("#contenedor-trataminetos-cel").addClass( "oculto" );
    $("#contenedor-testimonios-cel").addClass( "oculto" );


    $("#divEstudios-cel" ).click(function() {       
        $("#divCertificados-cel").removeClass( "boton-carrusel-hover");
        $("#spanCertificados").removeClass( "spanhover");
        $("#divPublicaciones-cel").removeClass( "boton-carrusel-hover");
        $("#spanPublicaciones").removeClass( "spanhover");
        $("#divAsociaciones-cel").removeClass( "boton-carrusel-hover");
        $("#spanAsociaciones").removeClass( "spanhover");
        $("#divProcedimientos-cel").removeClass( "boton-carrusel-hover");
        $("#spanProcedimientos").removeClass( "spanhover");
        $("#divTrataminetos-cel").removeClass( "boton-carrusel-hover");
        $("#spanTratamientos").removeClass( "spanhover");
        $("#divTestimonios-cel").removeClass( "boton-carrusel-hover");
        $("#spanTestimonios").removeClass( "spanhover");
        $("#divEstudios-cel").addClass( "boton-carrusel-hover");
        $("#spanEstudios").addClass( "spanhover");

        $("#contenedor-certificados-cel").addClass( "oculto" );
        $("#contenedor-publicaciones-cel").addClass( "oculto" );
        $("#contenedor-asociaciones-cel").addClass( "oculto" );
        $("#contenedor-procedimientos-cel").addClass( "oculto" );
        $("#contenedor-trataminetos-cel").addClass( "oculto" );
        $("#contenedor-testimonios-cel").addClass( "oculto" );
        $("#contenedor-estudios-cel").removeClass( "oculto" )
    }); 

    $("#divCertificados-cel" ).click(function() {
        $("#divPublicaciones-cel").removeClass( "boton-carrusel-hover");
        $("#spanPublicaciones").removeClass( "spanhover");
        $("#divAsociaciones-cel").removeClass( "boton-carrusel-hover");
        $("#spanAsociaciones").removeClass( "spanhover");
        $("#divProcedimientos-cel").removeClass( "boton-carrusel-hover");
        $("#spanProcedimientos").removeClass( "spanhover");
        $("#divTrataminetos-cel").removeClass( "boton-carrusel-hover");
        $("#spanTratamientos").removeClass( "spanhover");
        $("#divTestimonios-cel").removeClass( "boton-carrusel-hover");
        $("#spanTestimonios").removeClass( "spanhover");
        $("#divEstudios-cel").removeClass( "boton-carrusel-hover");
        $("#spanEstudios").removeClass( "spanhover");
        $("#divCertificados-cel").addClass( "boton-carrusel-hover");
        $("#spanCertificados").addClass( "spanhover");


        $("#contenedor-certificados-cel").removeClass( "oculto" );
        $("#contenedor-publicaciones-cel").addClass( "oculto" );
        $("#contenedor-asociaciones-cel").addClass( "oculto" );
        $("#contenedor-procedimientos-cel").addClass( "oculto" );
        $("#contenedor-trataminetos-cel").addClass( "oculto" );
        $("#contenedor-testimonios-cel").addClass( "oculto" );
        $("#contenedor-estudios-cel").addClass( "oculto" )
    });  

    $("#divPublicaciones-cel" ).click(function() {
        $("#divAsociaciones-cel").removeClass( "boton-carrusel-hover");
        $("#spanAsociaciones").removeClass( "spanhover");
        $("#divProcedimientos-cel").removeClass( "boton-carrusel-hover");
        $("#spanProcedimientos").removeClass( "spanhover");
        $("#divTrataminetos-cel").removeClass( "boton-carrusel-hover");
        $("#spanTratamientos").removeClass( "spanhover");
        $("#divTestimonios-cel").removeClass( "boton-carrusel-hover");
        $("#spanTestimonios").removeClass( "spanhover");
        $("#divEstudios-cel").removeClass( "boton-carrusel-hover");
        $("#spanEstudios").removeClass( "spanhover");
        $("#divCertificados-cel").removeClass( "boton-carrusel-hover");
        $("#spanCertificados").removeClass( "spanhover");
        $("#divPublicaciones-cel").addClass( "boton-carrusel-hover");
        $("#spanPublicaciones").addClass( "spanhover");


        $("#contenedor-certificados-cel").addClass( "oculto" );
        $("#contenedor-publicaciones-cel").removeClass( "oculto" );
        $("#contenedor-asociaciones-cel").addClass( "oculto" );
        $("#contenedor-procedimientos-cel").addClass( "oculto" );
        $("#contenedor-trataminetos-cel").addClass( "oculto" );
        $("#contenedor-testimonios-cel").addClass( "oculto" );
        $("#contenedor-estudios-cel").addClass( "oculto" )
    });
    
    
    $("#divAsociaciones-cel" ).click(function() {
        $("#divProcedimientos-cel").removeClass( "boton-carrusel-hover");
        $("#spanProcedimientos").removeClass( "spanhover");
        $("#divTrataminetos-cel").removeClass( "boton-carrusel-hover");
        $("#spanTratamientos").removeClass( "spanhover");
        $("#divTestimonios-cel").removeClass( "boton-carrusel-hover");
        $("#spanTestimonios").removeClass( "spanhover");
        $("#divEstudios-cel").removeClass( "boton-carrusel-hover");
        $("#spanEstudios").removeClass( "spanhover");
        $("#divCertificados-cel").removeClass( "boton-carrusel-hover");
        $("#spanCertificados").removeClass( "spanhover");
        $("#divPublicaciones-cel").removeClass( "boton-carrusel-hover");
        $("#spanPublicaciones").removeClass( "spanhover");
        $("#divAsociaciones-cel").addClass( "boton-carrusel-hover");
        $("#spanAsociaciones").addClass( "spanhover");


        $("#contenedor-certificados-cel").addClass( "oculto" );
        $("#contenedor-publicaciones-cel").addClass( "oculto" );
        $("#contenedor-asociaciones-cel").removeClass( "oculto" );
        $("#contenedor-procedimientos-cel").addClass( "oculto" );
        $("#contenedor-trataminetos-cel").addClass( "oculto" );
        $("#contenedor-testimonios-cel").addClass( "oculto" );
        $("#contenedor-estudios-cel").addClass( "oculto" )
    });

    $("#divProcedimientos-cel" ).click(function() {
        $("#divTrataminetos-cel").removeClass( "boton-carrusel-hover");
        $("#spanTratamientos").removeClass( "spanhover");
        $("#divTestimonios-cel").removeClass( "boton-carrusel-hover");
        $("#spanTestimonios").removeClass( "spanhover");
        $("#divEstudios-cel").removeClass( "boton-carrusel-hover");
        $("#spanEstudios").removeClass( "spanhover");
        $("#divCertificados-cel").removeClass( "boton-carrusel-hover");
        $("#spanCertificados").removeClass( "spanhover");
        $("#divPublicaciones-cel").removeClass( "boton-carrusel-hover");
        $("#spanPublicaciones").removeClass( "spanhover");
        $("#divAsociaciones-cel").removeClass( "boton-carrusel-hover");
        $("#spanAsociaciones").removeClass( "spanhover");
        $("#divProcedimientos-cel").addClass( "boton-carrusel-hover");
        $("#spanProcedimientos").addClass( "spanhover");


        $("#contenedor-certificados-cel").addClass( "oculto" );
        $("#contenedor-publicaciones-cel").addClass( "oculto" );
        $("#contenedor-asociaciones-cel").addClass( "oculto" );
        $("#contenedor-procedimientos-cel").removeClass( "oculto" );
        $("#contenedor-trataminetos-cel").addClass( "oculto" );
        $("#contenedor-testimonios-cel").addClass( "oculto" );
        $("#contenedor-estudios-cel").addClass( "oculto" )
    });

    $("#divTrataminetos-cel" ).click(function() {
        $("#divTestimonios-cel").removeClass( "boton-carrusel-hover");
        $("#spanTestimonios").removeClass( "spanhover");
        $("#divEstudios-cel").removeClass( "boton-carrusel-hover");
        $("#spanEstudios").removeClass( "spanhover");
        $("#divCertificados-cel").removeClass( "boton-carrusel-hover");
        $("#spanCertificados").removeClass( "spanhover");
        $("#divPublicaciones-cel").removeClass( "boton-carrusel-hover");
        $("#spanPublicaciones").removeClass( "spanhover");
        $("#divAsociaciones-cel").removeClass( "boton-carrusel-hover");
        $("#spanAsociaciones").removeClass( "spanhover");
        $("#divProcedimientos-cel").removeClass( "boton-carrusel-hover");
        $("#spanProcedimientos").removeClass( "spanhover");
        $("#divTrataminetos-cel").addClass( "boton-carrusel-hover");
        $("#spanTratamientos").addClass( "spanhover");


        $("#contenedor-certificados-cel").addClass( "oculto" );
        $("#contenedor-publicaciones-cel").addClass( "oculto" );
        $("#contenedor-asociaciones-cel").addClass( "oculto" );
        $("#contenedor-procedimientos-cel").addClass( "oculto" );
        $("#contenedor-trataminetos-cel").removeClass( "oculto" );
        $("#contenedor-testimonios-cel").addClass( "oculto" );
        $("#contenedor-estudios-cel").addClass( "oculto" )
    });
    
    $("#divTestimonios-cel" ).click(function() {
        $("#divEstudios-cel").removeClass( "boton-carrusel-hover");
        $("#spanEstudios").removeClass( "spanhover");
        $("#divCertificados-cel").removeClass( "boton-carrusel-hover");
        $("#spanCertificados").removeClass( "spanhover");
        $("#divPublicaciones-cel").removeClass( "boton-carrusel-hover");
        $("#spanPublicaciones").removeClass( "spanhover");
        $("#divAsociaciones-cel").removeClass( "boton-carrusel-hover");
        $("#spanAsociaciones").removeClass( "spanhover");
        $("#divProcedimientos-cel").removeClass( "boton-carrusel-hover");
        $("#spanProcedimientos").removeClass( "spanhover");
        $("#divTrataminetos-cel").removeClass( "boton-carrusel-hover");
        $("#spanTratamientos").removeClass( "spanhover");
        $("#divTestimonios-cel").addClass( "boton-carrusel-hover");
        $("#spanTestimonios").addClass( "spanhover");

        $("#contenedor-certificados-cel").addClass( "oculto" );
        $("#contenedor-publicaciones-cel").addClass( "oculto" );
        $("#contenedor-asociaciones-cel").addClass( "oculto" );
        $("#contenedor-procedimientos-cel").addClass( "oculto" );
        $("#contenedor-trataminetos-cel").addClass( "oculto" );
        $("#contenedor-testimonios-cel").removeClass( "oculto" );
        $("#contenedor-estudios-cel").addClass( "oculto" )
    });  
})


//función para cambiar estilos al hacer hover sobre el elemento
function sobre(objeto) {
    //esta linea toma todas las etiquetas img que se 
    //encuentran dentro del div con clase contenedor
    var imagen = objeto.getElementsByTagName('img');

    switch (objeto.id) {
        case 'whats':
            //cambia el valor del atributo src de la imagen
            imagen[0].src = 'http://sprofesional.zaabra.co/img/WhatsappBusiness-Hover-Icono.png';
            break;
        case 'face':
            imagen[0].src = 'http://sprofesional.zaabra.co/img/Facebook-Hover-Icono.png';
            break;
        case 'instag':
            imagen[0].src = 'http://sprofesional.zaabra.co/img/Instagram-Hover-Icono.png';
            break;
        case 'twitt':
            imagen[0].src = 'http://sprofesional.zaabra.co/img/Twitter-Hover-Icono.png';
            break;
        case 'yout':
            imagen[0].src = 'http://sprofesional.zaabra.co/img/Youtube-Hover-Icono.png';
            break;
        case 'mail':
            imagen[0].src = 'http://sprofesional.zaabra.co/img/infoProfesionales/Correo-Hover-Icono.png';
            break;   
        case 'favo':
            imagen[0].src = 'http://localhost:8000/img/Iconos-FavoritosSeleccionado.jpg';
            break;   
        default:
            break;
    }

}

//función para restablecer los estilos al quitar el mause del elemento
function salir(objeto) {
    var imagen = objeto.getElementsByTagName('img');

    switch (objeto.id) {
        case 'whats':
            imagen[0].src = 'https://sprofesional.zaabra.co/img/WhatsappBusiness-Icono.png';
            break;
        case 'face':
            imagen[0].src = 'https://sprofesional.zaabra.co/img/Facebook-Icono.png';
            console.log(objeto.id);
            break;
        case 'instag':
            imagen[0].src = 'https://sprofesional.zaabra.co/img/Instagram-Icono.png';
            console.log(objeto.id);
            break;
        case 'twitt':
            imagen[0].src = 'https://sprofesional.zaabra.co/img/Twitter-Icono.png';
            console.log(objeto.id);
            break;
        case 'yout':
            imagen[0].src = 'https://sprofesional.zaabra.co/img/Youtube-Icono.png';
            console.log(objeto.id);
            break;
        case 'mail':
            imagen[0].src = 'http://sprofesional.zaabra.co/img/infoProfesionales/Correo-Icono.png';
            break; 
            case 'favo':
                imagen[0].src = 'http://localhost:8000/img/Iconos-Favoritos.jpg';
                break;   
        default:
            break;
    }

}

$('#icono-desplegar-landing').click(function() {
    $('#contenedor-span-landing').removeClass("contenedor-span-landing ");
    $('#contenedor-span-landing').addClass(" contenedor-span-landing-click");
});

$(document).ready(function(){
    $("#guardarTestimonio").bind("submit",function(){
        
        $.ajax({
            type: $(this).attr("method"),
            url: $(this).attr("action"),
            data:$(this).serialize(),
            beforeSend: function(){

            },
            complete:function(data){
                debugger;
                $('#tempBloqueComentarios').html('');
               
                var i = 1;
                tamañoTestimonios = JSON.parse(data.responseText).length;
                data = JSON.parse(data.responseText);
                data.forEach(item => {
                    $("#tempBloqueComentarios").append(
                        (i > 1 ? '<div  class="collapse multi-collapse" >'  : '' )               
                        +'<div class="col-md-12 usuarioComentario" >'+
                            '<span class="nombre-verificado font-weight-bold font-sizetitulos">'+item.name+'</span>'+
                        '</div>'+
                        '<div class="col-md-12 comentario">'+
                            '<span class="text-uppercase text-black font-sizesubtitulos">'+item.comentario+'</span>'+
                        '</div>'+
                        '<div class="col-md-12 row comentario noPadMar">'+
                        (item.calificacion == 0 ? 
                        '<span  class="far fa-star color-verde "></span>'+
                         '<span  class="far fa-star color-verde "></span>'+
                         '<span  class="far fa-star color-verde "></span>'+
                         '<span  class="far fa-star color-verde "></span>'+
                         '<span  class="far fa-star color-verde "></span>'
                         : '') +
                         (item.calificacion == 1 ? 
                         '<span  class="fas fa-star color-verde "></span>'+
                         '<span  class="far fa-star color-verde "></span>'+
                         '<span  class="far fa-star color-verde "></span>'+
                         '<span  class="far fa-star color-verde "></span>'+
                         '<span  class="far fa-star color-verde "></span>'
                         : '') +
                         (item.calificacion == 2 ? 
                         '<span  class="fas fa-star color-verde "></span>'+
                         '<span  class="fas fa-star color-verde "></span>'+
                         '<span  class="far fa-star color-verde "></span>'+
                         '<span  class="far fa-star color-verde "></span>'+
                         '<span  class="far fa-star color-verde "></span>'
                         : '') +
                         (item.calificacion == 3 ? 
                         '<span  class="fas fa-star color-verde "></span>'+
                         '<span  class="fas fa-star color-verde "></span>'+
                         '<span  class="fas fa-star color-verde "></span>'+
                         '<span  class="far fa-star color-verde "></span>'+
                         '<span  class="far fa-star color-verde "></span>'
                         : '') +
                         (item.calificacion == 4 ? 
                         '<span  class="fas fa-star color-verde "></span>'+
                         '<span  class="fas fa-star color-verde "></span>'+
                         '<span  class="fas fa-star color-verde "></span>'+
                         '<span  class="fas fa-star color-verde "></span>'+
                         '<span  class="far fa-star color-verde " ></span>'
                         : '') +
                         
                         (item.calificacion == 5 ? 
                         '<span  class="fas fa-star color-verde "></span>'+
                         '<span  class="fas fa-star color-verde "></span>'+
                         '<span  class="fas fa-star color-verde "></span>'+
                         '<span  class="fas fa-star color-verde "></span>'+
                         '<span  class="fas fa-star color-verde "></span>'
                         : '')
                      +'</div>'+

                        (i > 1 ? '</div>'  : '' )
                        
                        )
                    i++;
                })
            }

        })
        debugger;
        // Nos permite cancelar el envio del formulario
        return false;

   
       
    })

})




function enviarFavorito(){
    datos = { 'usuarioLandingPage' : $('#usuarioLandingPage').val()}; 
    $.ajaxSetup({
        headers: {
            'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
        }
    });
    $.ajax({
        dataType: "json",
        url: 'http://localhost:8000/selecFavorito',
        data: datos,
        method: "POST",
        beforeSend: function(){
        },
        complete:function(data){
           respuesta = data.responseText;
           
           if (respuesta =="Guardo") {
            new Toast({
                message: 'Se ha agregado a favoritos',
                type: 'success'
              });
           }else{
            new Toast({
                message: 'Se ha eliminado de favoritos',
                type: 'danger'
              });
           }


        }
    })
    return false;
}


// Esto para el click de la imagen
$(document).ready(function() {

     // Esto es para la version computador
    $("#img-banner-hijo-landing1").addClass( "oculta-img-landing" );
    $("#img-banner-hijo-landing2").addClass( "oculta-img-landing" );
    $("#img-banner-hijo-landing3").addClass( "oculta-img-landing" );
    $("#img-banner-hijo-landing4").addClass( "oculta-img-landing" );
    $("#img-banner-hijo-landing5").addClass( "oculta-img-landing" );
    $("#img-banner-hijo-landingULTIMO").addClass( "oculta-img-landing" );

    // Esto es para la version cel
    $("#img-banner-hijo-landing-cel1").addClass( "oculta-img-landing" );
    $("#img-banner-hijo-landing-cel2").addClass( "oculta-img-landing" );
    $("#img-banner-hijo-landing-cel3").addClass( "oculta-img-landing" );
    $("#img-banner-hijo-landing-cel4").addClass( "oculta-img-landing" );
    $("#img-banner-hijo-landing-cel5").addClass( "oculta-img-landing" );
    $("#img-banner-hijo-landingULTIMO-cel").addClass( "oculta-img-landing" );


// Esto es para la version computador
    $("#div-carrusel-lending-padre1" ).click(function() {
        $("#banner-landing-Page").addClass("oculta-img-landing");
        $("#img-banner-hijo-landing1").removeClass( "oculta-img-landing" );
        $("#img-banner-hijo-landing2").addClass( "oculta-img-landing" );
        $("#img-banner-hijo-landing3").addClass( "oculta-img-landing" );
        $("#img-banner-hijo-landing4").addClass( "oculta-img-landing" );
        $("#img-banner-hijo-landing5").addClass( "oculta-img-landing" );
        $("#img-banner-hijo-landingULTIMO").addClass( "oculta-img-landing" );
        
    });

    $("#div-carrusel-lending-padre2" ).click(function() {
        $("#banner-landing-Page").addClass("oculta-img-landing");
        $("#img-banner-hijo-landing1").addClass( "oculta-img-landing" );
        $("#img-banner-hijo-landing2").removeClass( "oculta-img-landing" );
        $("#img-banner-hijo-landing3").addClass( "oculta-img-landing" );
        $("#img-banner-hijo-landing4").addClass( "oculta-img-landing" );
        $("#img-banner-hijo-landing5").addClass( "oculta-img-landing" );
        $("#img-banner-hijo-landingULTIMO").addClass( "oculta-img-landing" );
        
    });

    $("#div-carrusel-lending-padre3" ).click(function() {
        $("#banner-landing-Page").addClass("oculta-img-landing");
        $("#img-banner-hijo-landing1").addClass( "oculta-img-landing" );
        $("#img-banner-hijo-landing2").addClass( "oculta-img-landing" );
        $("#img-banner-hijo-landing3").removeClass( "oculta-img-landing" );
        $("#img-banner-hijo-landing4").addClass( "oculta-img-landing" );
        $("#img-banner-hijo-landing5").addClass( "oculta-img-landing" );
        $("#img-banner-hijo-landingULTIMO").addClass( "oculta-img-landing" );
        
    });
    $("#div-carrusel-lending-padre4" ).click(function() {
        $("#banner-landing-Page").addClass("oculta-img-landing");
        $("#img-banner-hijo-landing1").addClass( "oculta-img-landing" );
        $("#img-banner-hijo-landing2").addClass( "oculta-img-landing" );
        $("#img-banner-hijo-landing3").addClass( "oculta-img-landing" );
        $("#img-banner-hijo-landing4").removeClass( "oculta-img-landing" );
        $("#img-banner-hijo-landing5").addClass( "oculta-img-landing" );
        $("#img-banner-hijo-landingULTIMO").addClass( "oculta-img-landing" );
        
    });
    $("#div-carrusel-lending-padre5" ).click(function() {
        $("#banner-landing-Page").addClass("oculta-img-landing");
        $("#img-banner-hijo-landing1").addClass( "oculta-img-landing" );
        $("#img-banner-hijo-landing2").addClass( "oculta-img-landing" );
        $("#img-banner-hijo-landing3").addClass( "oculta-img-landing" );
        $("#img-banner-hijo-landing4").addClass( "oculta-img-landing" );
        $("#img-banner-hijo-landing5").removeClass( "oculta-img-landing" );
        $("#img-banner-hijo-landingULTIMO").addClass( "oculta-img-landing" );
        
    });
    $("#div-carrusel-lending-padreULTIMO" ).click(function() {
        $("#banner-landing-Page").addClass("oculta-img-landing");
        $("#img-banner-hijo-landing1").addClass( "oculta-img-landing" );
        $("#img-banner-hijo-landing2").addClass( "oculta-img-landing" );
        $("#img-banner-hijo-landing3").addClass( "oculta-img-landing" );
        $("#img-banner-hijo-landing4").addClass( "oculta-img-landing" );
        $("#img-banner-hijo-landing5").addClass( "oculta-img-landing" );
        $("#img-banner-hijo-landingULTIMO").removeClass( "oculta-img-landing" );
        
    });

// Esto es para la version cel
    $("#div-carrusel-lending-padre-cel1" ).click(function() {
        $("#banner-landing-Page-cel").addClass("oculta-img-landing");
        $("#img-banner-hijo-landing-cel1").removeClass( "oculta-img-landing" );
        $("#img-banner-hijo-landing-cel2").addClass( "oculta-img-landing" );
        $("#img-banner-hijo-landing-cel3").addClass( "oculta-img-landing" );
        $("#img-banner-hijo-landing-cel4").addClass( "oculta-img-landing" );
        $("#img-banner-hijo-landing-cel5").addClass( "oculta-img-landing" );
        $("#img-banner-hijo-landingULTIMO-cel").addClass( "oculta-img-landing");
    });
    $("#div-carrusel-lending-padre-cel2" ).click(function() {
        $("#banner-landing-Page-cel").addClass("oculta-img-landing");
        $("#img-banner-hijo-landing-cel1").addClass( "oculta-img-landing" );
        $("#img-banner-hijo-landing-cel2").removeClass( "oculta-img-landing" );
        $("#img-banner-hijo-landing-cel3").addClass( "oculta-img-landing" );
        $("#img-banner-hijo-landing-cel4").addClass( "oculta-img-landing" );
        $("#img-banner-hijo-landing-cel5").addClass( "oculta-img-landing" );
        $("#img-banner-hijo-landingULTIMO-cel").addClass( "oculta-img-landing");
    });
    $("#div-carrusel-lending-padre-cel3" ).click(function() {
        $("#banner-landing-Page-cel").addClass("oculta-img-landing");
        $("#img-banner-hijo-landing-cel1").addClass( "oculta-img-landing" );
        $("#img-banner-hijo-landing-cel2").addClass( "oculta-img-landing" );
        $("#img-banner-hijo-landing-cel3").removeClass( "oculta-img-landing" );
        $("#img-banner-hijo-landing-cel4").addClass( "oculta-img-landing" );
        $("#img-banner-hijo-landing-cel5").addClass( "oculta-img-landing" );
        $("#img-banner-hijo-landingULTIMO-cel").addClass( "oculta-img-landing");
    });
    $("#div-carrusel-lending-padre-cel4" ).click(function() {
        $("#banner-landing-Page-cel").addClass("oculta-img-landing");
        $("#img-banner-hijo-landing-cel1").addClass( "oculta-img-landing" );
        $("#img-banner-hijo-landing-cel2").addClass( "oculta-img-landing" );
        $("#img-banner-hijo-landing-cel3").addClass( "oculta-img-landing" );
        $("#img-banner-hijo-landing-cel4").removeClass( "oculta-img-landing" );
        $("#img-banner-hijo-landing-cel5").addClass( "oculta-img-landing" );
        $("#img-banner-hijo-landingULTIMO-cel").addClass( "oculta-img-landing");
    });
    $("#div-carrusel-lending-padre-cel5" ).click(function() {
        $("#banner-landing-Page-cel").addClass("oculta-img-landing");
        $("#img-banner-hijo-landing-cel1").addClass( "oculta-img-landing" );
        $("#img-banner-hijo-landing-cel2").addClass( "oculta-img-landing" );
        $("#img-banner-hijo-landing-cel3").addClass( "oculta-img-landing" );
        $("#img-banner-hijo-landing-cel4").addClass( "oculta-img-landing" );
        $("#img-banner-hijo-landing-cel5").removeClass( "oculta-img-landing" );
        $("#img-banner-hijo-landingULTIMO-cel").addClass( "oculta-img-landing");
    });
    $("#div-carrusel-lending-padreULTIMO-cel" ).click(function() {
        $("#banner-landing-Page-cel").addClass("oculta-img-landing");
        $("#img-banner-hijo-landing-cel1").addClass( "oculta-img-landing" );
        $("#img-banner-hijo-landing-cel2").addClass( "oculta-img-landing" );
        $("#img-banner-hijo-landing-cel3").addClass( "oculta-img-landing" );
        $("#img-banner-hijo-landing-cel4").addClass( "oculta-img-landing" );
        $("#img-banner-hijo-landing-cel5").addClass( "oculta-img-landing" );
        $("#img-banner-hijo-landingULTIMO-cel").removeClass( "oculta-img-landing");
    });

});

               


