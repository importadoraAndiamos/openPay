$('#reveal-click').click(function() {

    $(this).toggleClass("active");
    if ($(this).hasClass("active")) {
        $(this).text("Ver Menos");
    } else {
        $(this).text("Ver mas");
    }

    $('#reveal-wrap #hidden-div').slideToggle({
        direction: "up"
    }, 300);
    $(this).toggleClass('clientsClose');


}); // end click

$('#reveal-click2').click(function() {

    $(this).toggleClass("active2");
    if ($(this).hasClass("active2")) {
        $(this).text("Ver Menos");
    } else {
        $(this).text("Ver mas");
    }

    $('#reveal-wrap2 #hidden-div2').slideToggle({
        direction: "up"
    }, 300);
    $(this).toggleClass('clientsClose2');


}); // end click


    function redireccion_preguntas() {
        $("#preguntas").removeClass( "oculta-Div-quienes" );
        window.location.href="/quienes#preguntas";
    }



